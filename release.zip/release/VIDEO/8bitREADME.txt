this is the video section of the 8bit breadboard computer.

firstly, the breadboard computer does have a video card, which generates composite black&white signals
into a TV.

i never wrote down schematics for the video card though and built it from my mind, so what I did was to
attach the schematics of a similar video card made by someone else. that should do the job.

my car was quite different from that one however, but they do the same job.

Daniel's card seems to use ripple counters to generate the video, and the problem with that is that
the bits change one after the other and that causes glitches. I think he fixed the glitches by attaching capacitors here and there on the lines.

my solution was to never send the counts into the circuit until the counter had settled, i.e. i synchronized.

i synchronized it by sending the counters into d-flip flops first, and then at the next clock edge the signals are read
by the synch generators, this way there will never be spurious synch signals.

enjoy!
