typedef struct {
	U4 CODE_SIZE;
	U4 DATA_SIZE;
	U4 STACK_SIZE;
} _HEADER;

/* not used at the moment
typedef enum {
	R = 1, IM
} _OPERAND_TYPE;*/

typedef enum {
	DT_BYTE = 1, DT_WORD, DT_DWORD
} _DATATYPE;

struct {
	char *regStr;
	int reg;
} regTable[] = {
	"pc",	PC,		/* instruction pointer */
	"a",	A,		/* accumulator register */
	"b", 	B,		/* base register */
	"",		-1
};
