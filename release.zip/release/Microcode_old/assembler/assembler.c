/*
	began on: 09/March/2013
	assembles AASM into binary code
	
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>
#include "commondef.h"
#include "common.h"
#include "opcode.h"
#include "aheader.h"

int dbg(char *s){
	puts(s);
	getchar();
}

void declareMacros(void){
	static char incl[MACRO_INCL_LEN];
	char *p, *t;
	int paramIndex;
	prog = TXT_IN;
	do{
		gettok();
		if(tok == T_DOT){
			gettok();
			if(scmp(tokstr, "def")){
				gettok();
				strcpy(macroDefTable[macroDefIndex].defName, tokstr);
				p = macroDefTable[macroDefIndex].text;
				while(*prog != '\n' && *prog){
					if(*prog == '\\'){
						*p++ = '\n';
						prog++;
						while(isspace(*prog)) prog++;
					}
					*p++ = *prog++;
				}
				trim(macroDefTable[macroDefIndex].text);
				macroDefIndex++;
			}
			else if(scmp(tokstr, "incl")){
				gettok();
				loadFile(incl, tokstr);
				*prog++ = 13;
				*prog++ = 10;
				insert(TXT_IN, incl, prog);
			}
		}
	} while(tok != T_END);
}

void expandMacros(void){
	int macroIndex;
	prog = TXT_IN;
	do{
		gettok();
		if(toktype == ID){
			if((macroIndex = findDefMacro(tokstr)) != -1){
				putback();
				erase(TXT_IN, prog, strlen(tokstr));
				insert(TXT_IN, macroDefTable[macroIndex].text, prog);
			}
		}
		else if(tok == T_DOT) feol();
	} while(tok != T_END);
}

void skipDefMacro(void){
	while(*prog != '\n' && *prog) prog++;
}

int findDefMacro(char *defName){
	register int i;
	for(i = 0; i < macroDefIndex; i++)
		if(scmp(macroDefTable[i].defName, defName)) return i;
	return -1;
}

int scmp(char *s1, char *s2){
	return !strcmp(s1, s2);
}

int main(){
	int i;
	loadFile(TXT_IN, "in.dasm");
	declareMacros();
	expandMacros();

	write("out.avm");

	puts("Labels:");
	for(i = 0; i < lblIndex; i++){
		printf("%s: %d\n", lblTable[i].lblname, lblTable[i].codeloc);
	}

	puts("Compilation finished.");
	return 0;
}

int getDataSize(_DATATYPE dataType){
	switch(dataType){
		case DT_BYTE:
			return sizeof(BYTE);
		case DT_WORD:
			return sizeof(WORD);
		case DT_DWORD:
			return sizeof(DWORD);
		default:
			err(UNKNOWN_DATA_TYPE, "");
	}
}

_DATATYPE getDataType(_ATOM tok){
	switch(tok){
		case T_DTBYTE:
			return (DT_BYTE);
		case T_DTWORD:
			return (DT_WORD);
		case T_DTDWORD:
			return (DT_DWORD);
		default:
			err(UNKNOWN_DATA_TYPE, "");
	}
}


int initData(_DATATYPE dt){
	U4 dIndex = dataIndex;
	register U4 i;
	do{
		gettok();
		switch(dt){
			case DT_BYTE:
				if(toktype == STR_CONST){
					for(i = 0; tokstr[i]; i++)
						*(U1*)(DATA + dIndex++) = tokstr[i]; /* sizeof(char) assumed to be one (dIndex++)  */
				}
				else *(S1*)(DATA + dIndex++) = (S1)strToInt(tokstr);
				break;
			case DT_WORD:
				*(WORD*)(DATA + dIndex) = (WORD)strToInt(tokstr);
				dIndex += sizeof(WORD);
				break;
			case DT_DWORD:
				*(DWORD*)(DATA + dIndex) = (DWORD)strToInt(tokstr);
				dIndex += sizeof(DWORD);
				break;
		}
		gettok();
	} while(tok == T_COMMA);
	putback();
	return dIndex - dataIndex;
}

void write(char *filename){
	FILE *fp;
	int i;
	_HEADER header;
	if((fp = fopen(filename, "wb")) == NULL){
		printf("failed to create output file");
		exit(1);
	}
	header.CODE_SIZE = outIndex;
	header.DATA_SIZE = dataIndex;
	fwrite(&header, sizeof(_HEADER), 1, fp);
	fwrite(BYTECODE_OUT, sizeof(BYTE), outIndex, fp);	// writes the program binary data
	fwrite(DATA, sizeof(BYTE), dataIndex, fp);
	fclose(fp);
}

void trim(char *s){
	char *start = s, *end = s;
	char *p = s;
	int sb = 0;
	while(*end) end++;
	end--;
	while(isspace(*start)){
		start++;
		sb++;
	}
	while(isspace(*end)) *end--;
	for(p = start; p <= end; p++) *(p - sb) = *p;
	*(end - sb + 1) = '\0';
}

void erase(char *s, char *pos, int len){
	char *p = pos;
	for(p = pos; p < pos + len; p++) *p = ' ';
}

void insert(char *text, char *s, char *pos){
	int slen = strlen(s);
	char *p = text;
	char *end = text;
	int i = 0;
	while(*end) end++;
	for(p = end; p >= pos; p--) *(p + slen) = *p;
	for(p = pos; p < pos + slen; p++) *p = s[i++];
	*(end + slen) = '\0';
}

void declareLabels(void){
	U4 codeloc = 0;
	char lblName[ID_LEN];
	gettok();
	if(tok == T_END || tok == T_DOT) return;
	else putback();
	do{
		gettok();
		if(toktype == ID){
			strcpy(lblName, tokstr);
			gettok();
			if(tok != T_COLON) continue;
			if(labelExists(lblName)) err(REDECLARED_LABEL, lblName);
			strcpy(lblTable[lblIndex].lblname, lblName);
			lblTable[lblIndex].codeloc = codeloc;
			lblIndex++;
		}
		else if(toktype == KEYWORD){
			codeloc += getInstrLen(tokstr);
			feol();
		}
	} while(tok != T_DOT && tok != T_END);
}

int labelExists(char *lblName){
	register int i;
	for(i = 0; i < lblIndex; i++)
		if(scmp(lblTable[i].lblname, lblName)) return 1;
	return 0;
}

int getInstrLen(char *s){
	register int i;
	char s2[ID_LEN];
	strcpy(s2, s);
	toLower(s2);
	for(i = 0; *opcodeTable[i].mnemonic; i++)
		if(!strcmp(opcodeTable[i].mnemonic, s2)) return opcodeTable[i].len;

	err(UNKNOWN_INSTRUCTION, "");
}

void feol(void){
	while(*prog != '\n' && *prog) prog++;
	while(isspace(*prog)) prog++;
}

void parseCode(void){
	gettok();
	if(tok == T_END || tok == T_DOT) return;
	do{
		if(toktype == ID){		// label ?
			gettok(); // gets past the colon
			if(tok != T_COLON) err(UNKNOWN_INSTRUCTION, "");
			gettok();
			continue;
		}
		switch(tok){
			case T_MOV:
				parse_mov();
				break;
			case T_ADD:
				parse_arithmetic(ADD);
				break;
			case T_SUB:
				parse_arithmetic(SUB);
				break;
			case T_INC:
				parse_inc();
				break;
			case T_DEC:
				parse_dec();
				break;
			case T_AND:
				parse_bitwise(AND);
				break;
			case T_OR:
				parse_bitwise(OR);
				break;
			case T_XOR:
				parse_bitwise(XOR);
				break;
			case T_NOT:
				parse_not();
				break;
			case T_CMP:
				parse_cmp(CMP);
				break;
						

			case T_JZ:
				parse_jz();
				break;
			case T_JC:
				parse_jc();
				break;
			case T_JMP:
				parse_jmp();
				break;
			default:
				err(UNKNOWN_INSTRUCTION, tokstr);
		}
		gettok();
	} while(tok != T_DOT && tok != T_END);
}




void emitU4(U4 dw){
	*(U4*)(BYTECODE_OUT + outIndex) = dw;
	outIndex += 4;
}







int getInt(void){
	gettok();
	if(toktype != INT_CONST) err(INT_EXPECTED, "");
	return strToInt(tokstr);
}


void emit0(int n){
	int i;
	for(i = 0; i < n; i++) emitU1(0);
}

void parse_jz(){
	U4 codeloc;
	gettok(); // gets the label name
	codeloc = getLblLoc(tokstr);
	emitU1(JZ);
	emitU4(codeloc);
}

void parse_jc(){
	U4 codeloc;
	gettok(); // gets the label name
	codeloc = getLblLoc(tokstr);
	emitU1(JC);
	emitU4(codeloc);
}

void parse_jmp(){
	U4 codeloc;
	gettok(); // gets the label name
	codeloc = getLblLoc(tokstr);
	emitU1(JMP);
	emitU4(codeloc);
}


void parse_inc(void){
	BYTE regnum;
	regnum = getReg();
	emitU1(INC);
	emitU1(regnum);
}

void parse_dec(void){
	BYTE regnum;
	regnum = getReg();
	emitU1(DEC);
	emitU1(regnum);
}

void parse_not(void){
	BYTE regnum;
	regnum = getReg();
	emitU1(NOT);
	emitU1(regnum);
}
/* AND #4, #4
	AND #3, 2
	AND #1, @B */
void parse_bitwise(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_arithmetic(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

U1 getReg(void){
	int i;
	gettok();
	expect(T_REGNUM, REGNUM_EXPECTED);
	gettok();
	if(toktype == INT_CONST) return(strToInt(tokstr) + NUM_SPECIAL_REG);
	else if(toktype == ID){
		toLower(tokstr);
		for(i = 0; *regTable[i].regStr; i++)
			if(!strcmp(tokstr, regTable[i].regStr)) return regTable[i].reg;
	}
	err(INVALID_REGISTER, "");
}

U1 getfdReg(void){
	gettok();
	expect(T_REGNUM, REGNUM_EXPECTED);
	gettok();
	if(toktype == INT_CONST) return strToInt(tokstr);
	err(INVALID_REGISTER, "not a float or double register");
}

void parse_farithmetic(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_darithmetic(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_cmp(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_fcmp(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_dcmp(_OPCODE opcode){
	U1 reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(opcode);
	emitU1(reg1);
	emitU1(reg2);
}

void parse_mov(void){
	BYTE reg1, reg2;
	reg1 = getReg();
	gettok();
	if(tok != T_COMMA) err(SYNTAX_ERR, "");
	reg2 = getReg();
	emitU1(MOV);
	emitU1(reg1);
	emitU1(reg2);
}


U4 getDataOffset(char *dataName){
	int i;
	for(i = 0; i < dataIndex; i++)
		if(!strcmp(dataTable[i].dataName, dataName)) return dataTable[i].offset;
	err(UNDECLARED_DATA, dataName);
}

void emitU1(U1 b){
	BYTECODE_OUT[outIndex] = b;
	outIndex++;
}

void emitU2(U2 w){
	*(U2*)(BYTECODE_OUT + outIndex) = w;
	outIndex += sizeof(U2);
}

void putback(void){
	char *p = tokstr;
	while(*p++) prog--;
}

void loadFile(char *where, char *filename){
	char *p = where;
	FILE *fp;
	int i;
	if( (fp = fopen(filename, "rb")) == NULL){
		printf("failed to open file");
		exit(1);
	}
	p = where;
	i = 0;
	do{
		*p++ = fgetc(fp);
		i++;
	} while(!feof(fp) && i < IN_PROG_SIZE);
	fclose(fp);

	*(p - 1) = 13;
	*p = 10;
	*(p + 1) = '\0';
}

void gettok(void){
	char *tokp = tokstr;

	tok = -1;
	toktype = -1;
	*tokp = '\0';
	
	do{
		while(isspace(*prog)) prog++;
		if(*prog == ';')
			while(*prog != '\n' && *prog) prog++;
	} while(isspace(*prog));
	
	if(!*prog){
		tok = T_END;
		toktype = FINISHED;
		return;
	}
	
	if(*prog == '\"'){
		toktype = STR_CONST;
		prog++;
		while(*prog != '\"' && *prog) *tokp++ = *prog++;
		if(!*prog) err(UNTERMINATED_STRING, "");
		prog++;
		*tokp = '\0';
		return;
	}

	if(isDelim(*prog)){
		toktype = DELIM;
		switch(*prog){
			case '#':
			case '%':
			case '$':
				tok = T_REGNUM;
				break;
			case '@':
				tok = T_AT;
				break;
			case '/':
				tok = T_SLASH;
				break;
			case ',':
				tok = T_COMMA;
				break;
			case ':':
				tok = T_COLON;
				break;
			case '.':
				tok = T_DOT;
				break;
			case '=':
				tok = T_EQUAL;
				break;
			case '+':
				tok = T_PLUS;
				break;/*
			case '-':
				tok = T_MINUS;
				break;*/
			case '*':
				tok = T_TIMES;
				break;
			case '[':
				tok = T_LBRACKET;
				break;
			case ']':
				tok = T_RBRACKET;
				break;
			case '(':
				tok = T_LPAREN;
				break;
			case ')':
				tok = T_RPAREN;
				break;
			case '\\':
				tok = T_NEWLINE;
				break;
		}
		*tokp++ = *prog++;
		*tokp = '\0';
		return;
	}

	if(*prog == '-') *tokp++ = *prog++;
	if(isdigit(*prog)){
		if(*prog == '0' && tolower(*(prog+1)) == 'x'){
			*tokp++ = *prog++;
			*tokp++ = tolower(*prog++);
		}
		do{
			*tokp++ = *prog++; 
		} while(isdigit(*prog) || isHexDigit(*prog));
		if(*prog == '.'){
			*tokp++ = *prog++;
			while(isdigit(*prog)) *tokp++ = *prog++;
			if(*prog == 'D'){
				toktype = DBL_CONST;
				prog++;
			}
			else toktype = FLT_CONST;
		}
		else toktype = INT_CONST;
		*tokp = '\0';
		return;
	}

	if(isIdChar(*prog)){
		while(isIdChar(*prog) || isdigit(*prog)) *tokp++ = *prog++;
		*tokp = '\0';
		if((tok = find_keyword(tokstr)) != -1) toktype = KEYWORD;
		else toktype = ID;
		return;
	}
}

int isHexDigit(char c){
	char d = tolower(c);
	return d == 'a' || d == 'b' || d == 'c' || d == 'e' || d == 'f';
}

int find_keyword(char *keyword){
	char k[ID_LEN];
	register int i;
	strcpy(k, keyword);
	toLower(k);
	for(i = 0; *keywordTbl[i].keyword; i++)
		if(!strcmp(keywordTbl[i].keyword, k)) return keywordTbl[i].tok;
	return -1;
}

char *toLower(char *s){
	while(*s){
		if(isupper(*s)) *s += 32;
		s++;
	}
}

U4 getLblLoc(char *lblname){
	register int i;

	for(i = 0; i < lblIndex; i++)
		if(!strcmp(lblTable[i].lblname, lblname)) return lblTable[i].codeloc;
	
	err(UNDEFINED_LABEL, "");
}

void err(_ERROR_CODE code, char *info){
	int line = 1;
	char *p = TXT_IN;
	static char *msg[] = {
		"invalid operand",
		"undeclared variable",
		"opening brace expected",
		"closing brace expected",
		"identifier expected",
		"syntax error",
		"integer expected",
		"register operand expected",
		"register number expected",
		"unfinished directive",
		"unknown directive",
		"comma expected",
		"colon expected",
		"undefined label",
		"unterminated string",
		"no code segment found",
		"segment end expected",
		"unfinished data segment",
		"opening bracket expected",
		"closing bracket expected",
		"invalid array declaration",
		"base register expected",
		"data type expected",
		"stack size expected",
		"invalid program structure",
		"invalid register",
		"undeclared data",
		"unfinished string",
		"uninitialized open array",
		"incorrect label declaration (missing colon)",
		"unknown data type",
		"unknown instruction",
		"R paren expected",
		"redeclared label",
		"float or double expected",
		"float expected",
		"double expected"
	};
	while(p < prog){
		if(*p == '\n'){
			line++;
			p++;
		}
		p++;
	}
	puts(msg[code]);
	printf("additional info: %s\n", info);
	printf("line: %d\n\n", line);
	puts("press any key to exit.");
	getch();
	exit(1);
}

int isDelim(char c){
	if(strchr("@#,.:{}\"\'\\()[]/=+*^$%", c)) return 1;
	else return 0;
}

int isIdChar(char c){
	return isalpha(c) || c == '_';
}

int strToInt(char *s){
	char *p;
	int neg;
	
	if(*s == '-'){
		neg = 1;
		s++;
	}
	else neg = 0;
	if(*s == '0' && *(s+1) == 'x'){
		s += 2;
		if(neg) return -hexStrToInt(s);
		else return hexStrToInt(s);
	}
	if(neg) return -atoi(s);
	else return atoi(s);
}

int hexStrToInt(char *s){
	int len, i, result = 0;
	len = strlen(s);
	for(i = 0; i < len; i++) result += charToInt(s[len - i - 1]) * Pow(16, i);
	return result;
}

int Pow(int base, int exp){
	int i, result = base;
	if(!exp) return 1;
	for(i = 0; i < exp - 1; i++) result *= base;
	return result;
}

int charToInt(char c){
	if(strchr("ABCDEF", c)){
		return c - 'A' + 10;
	}
	else if(strchr("abcdef", c)){
		return c - 'a' + 10;
	}
	return c - '0';
}

void expect(int expectedTok, int error){
	if(tok != expectedTok) err(error, "");
}

int isLine(char c){
	return c == 10 || c == 13;
}

void reqComma(void){
	gettok();
	expect(T_COMMA, COMMA_EXPECTED);
}
