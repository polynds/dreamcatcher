#define ID_LEN					32
#define	IN_PROG_SIZE			2000 /* text input */
#define	OUT_PROG_SIZE			2000 /* bytecode output */
#define	LBL_TABLESIZE			255
#define	MAX_TOKEN_LEN			1024
#define	DATA_TBL_SIZE			255	/* for each individual data declaration */
#define	MAX_DATA_SIZE			1000 /* data buffer size */

#define	MACRO_INCL_LEN			1024
#define	MAX_MACRO_DEF			50
#define	MACRO_DEF_LEN			100

typedef enum {
	T_JZ,
	T_JC,
	T_JMP,
	
	T_MOV,
	T_ADD,
	T_SUB,
	T_INC,
	T_DEC,
	T_AND,
	T_OR,
	T_XOR,
	T_NOT,
	T_CMP,

	T_COMMA,
	T_AT,
	T_COLON,
	T_SLASH,
	T_DOT,
	T_REGNUM,
	T_EQUAL,
	T_LBRACKET,
	T_RBRACKET,
	T_LPAREN,
	T_RPAREN,
	T_PLUS,
	T_MINUS,
	T_TIMES,
	T_NEWLINE,

	T_DTBYTE,
	T_DTWORD,
	T_DTDWORD,
	T_DTFLT,
	T_DTDBL,
	
	T_END
} _ATOM;

typedef enum {
	INVALID_OPERAND,
	UNDECLARED_VAR,
	LBRACE_EXPECTED,
	RBRACE_EXPECTED,
	ID_EXPECTED,
	SYNTAX_ERR,
	INT_EXPECTED,
	REG_EXPECTED,
	REGNUM_EXPECTED,
	UNFINISHED_DIRECTIVE,
	UNKNOWN_DIRECTIVE,
	COMMA_EXPECTED,
	COLON_EXPECTED,
	UNDEFINED_LABEL,
	UNTERMINATED_STRING,
	NO_CODE_SEGMENT,
	SEGMENT_END_EXPECTED,
	UNFINISHED_DATA_SEGMENT,
	LBRACKET_EXPECTED,
	RBRACKET_EXPECTED,
	INVALID_ARRAY_DECLARATION,
	BASEREG_EXPECTED,
	DATATYPE_EXPECTED,
	STACK_SIZE_EXPECTED,
	INVALID_PROGRAM_STRUCTURE,
	INVALID_REGISTER,
	UNDECLARED_DATA,
	UNFINISHED_STRING,
	UNINITIALIZED_OPEN_ARRAY,
	BAD_LABEL,
	UNKNOWN_DATA_TYPE,
	UNKNOWN_INSTRUCTION,
	RPAREN_EXPECTED,
	REDECLARED_LABEL,
	FLT_OR_DBL_EXPECTED,
	FLT_EXPECTED,
	DBL_EXPECTED
} _ERROR_CODE;

typedef enum {
	KEYWORD, ID, DELIM, FINISHED,
	CHAR_LITERAL, INT_CONST, FLT_CONST, DBL_CONST, STR_CONST
} _TOK_TYPE;

typedef struct {
	char lblname[ID_LEN];
	U4 codeloc;
} _LABEL;

struct {
	char *keyword;
	_ATOM tok;
} keywordTbl[] = {
	"jz", 	T_JZ,	
	"jc", 	T_JC,
	"jmp", 	T_JMP,	
	
	"mov",	T_MOV,
	"add",	T_ADD,
	"sub",	T_SUB,
	"inc",	T_INC,
	"dec",	T_DEC,	
	"and", 	T_AND,	
	"or", 	T_OR,	
	"xor", 	T_XOR,	
	"not", 	T_NOT,	
	"cmp", 	T_CMP,
	
	"byte",	 		T_DTBYTE,
	"word",	 		T_DTWORD,
	"dword",			T_DTDWORD,
	
	"", 				-1
};

struct {
	char *s;
	_DATATYPE dt;
} dtToStr[] = {
	"byte",		DT_BYTE,
	"word", 		DT_WORD,
	"dword", 	DT_DWORD,
	"",			-1
};

struct {
	char defName[ID_LEN];
	char text[MACRO_DEF_LEN];
} macroDefTable[MAX_MACRO_DEF];
int macroDefIndex;

typedef struct {
	char dataName[ID_LEN];
	U4 offset;
} _DATA;

_DATA dataTable[DATA_TBL_SIZE];
U2 dataTableIndex;
U1 DATA[MAX_DATA_SIZE];
U4 dataIndex;

_LABEL lblTable[LBL_TABLESIZE];
int lblIndex;

char tokstr[MAX_TOKEN_LEN];
_ATOM tok;
_TOK_TYPE toktype;

BYTE TXT_IN[IN_PROG_SIZE];
char *prog;

U1 BYTECODE_OUT[OUT_PROG_SIZE]; // output program
U4 outIndex; // index into OUT

void declareLabels(void);
void parseCode(void);
void parseData(void);

void loadFile(char *where, char *filename);
void gettok(void);
int isDelim(char c);
int isIdChar(char c);
void err(_ERROR_CODE code, char *info);
int find_keyword(char *word);
int is_var(char *name);
void putback(void);
void feol(void);

void parse_mov(void);
void parse_jz(void);
void parse_jc(void);
void parse_jmp(void);
void parse_not(void);
void parse_inc(void);
void parse_dec(void);

void parse_cmp(_OPCODE opcode);

void parse_arithmetic(_OPCODE opcode);
void parse_bitwise(_OPCODE opcode);

void parse_lbi(void);
void parse_lwi(void);
void parse_lb(void);
void parse_sb(void);

U4 getLblLoc(char *lblname);
int labelExists(char *lblName);

void write(char *filename);

BYTE encode(BYTE optype1, BYTE optype2);
void emit0(int n);

void expect(int expectedTok, int error);
int getDataSize(_DATATYPE dataType);
int initData(_DATATYPE dt);
U4 getDataOffset(char *dataName);
U1 getReg(void);
void reqComma(void);
int getInt(void);

int charToInt(char c);
int Pow(int base, int exp);
int hexStrToInt(char *s);
int strToInt(char *s);
char *toLower(char *s);
int getInstrLen(char *s);
int isHexDigit(char c);

void emitU1(U1 bin);
void emitU2(U2 w);
void emitU4(U4 dw);
void emitFlt(float f);
void emitDbl(double d);

void erase(char* s, char* pos, int len);
void insert(char* text, char *s, char* pos);
void trim(char *s);
int scmp(char *s1, char *s2);

void declareMacros(void);
