microcode_old contains all the files for the youtube breadboard computer.

microcode_new contains microcode ideas for a new 16bit computer I'm designing.

so focus on the old one if you're interested in the youtube one.

i included schematics for both however.

and most importantly, all schematics here are not 100% complete. not yet.

most clock signals, mux enable signals, reset signals, for example are not shown.
so you need to use your brain.  
